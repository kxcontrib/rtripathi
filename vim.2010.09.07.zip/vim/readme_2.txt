The directory structure after we generate q.vim and k.vim should look as follows

./filetype.vim
./generate
./generate/kfooter.txt
./generate/kgenerate.q
./generate/kheader.txt
./generate/qfooter.txt
./generate/qgenerate.q
./generate/qheader.txt
./indent
./indent/k.vim
./indent/q.vim
./nested.vim
./readme.txt
./syntax
./syntax/k.vim
./syntax/q.vim
./vimrc


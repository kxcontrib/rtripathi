g++ -DHAVE_CONFIG_H -I. -I. -I.     -g -O2 -c idep_adep.cxx
g++ -DHAVE_CONFIG_H -I. -I. -I.     -g -O2 -c idep_altab.cxx
g++ -DHAVE_CONFIG_H -I. -I. -I.     -g -O2 -c idep_alutil.cxx
g++ -DHAVE_CONFIG_H -I. -I. -I.     -g -O2 -c idep_binrel.cxx
g++ -DHAVE_CONFIG_H -I. -I. -I.     -g -O2 -c idep_cdep.cxx
g++ -DHAVE_CONFIG_H -I. -I. -I.     -g -O2 -c idep_fdepitr.cxx
g++ -DHAVE_CONFIG_H -I. -I. -I.     -g -O2 -c idep_ldep.cxx
g++ -DHAVE_CONFIG_H -I. -I. -I.     -g -O2 -c idep_namea.cxx
g++ -DHAVE_CONFIG_H -I. -I. -I.     -g -O2 -c idep_nimap.cxx
g++ -DHAVE_CONFIG_H -I. -I. -I.     -g -O2 -c idep_string.cxx
g++ -DHAVE_CONFIG_H -I. -I. -I.     -g -O2 -c idep_tokitr.cxx
rm -f libidep.a
ar cru libidep.a idep_adep.o idep_altab.o idep_alutil.o idep_binrel.o idep_cdep.o idep_fdepitr.o idep_ldep.o idep_namea.o idep_nimap.o idep_string.o idep_tokitr.o 
ranlib libidep.a
g++ -DHAVE_CONFIG_H -I. -I. -I.     -g -O2 -c cdep.cxx
/bin/sh ./libtool --mode=link g++  -g -O2  -o cdep  cdep.o libidep.a 
mkdir .libs
g++ -g -O2 -o cdep cdep.o  libidep.a
g++ -DHAVE_CONFIG_H -I. -I. -I.     -g -O2 -c adep.cxx
/bin/sh ./libtool --mode=link g++  -g -O2  -o adep  adep.o libidep.a 
g++ -g -O2 -o adep adep.o  libidep.a
g++ -DHAVE_CONFIG_H -I. -I. -I.     -g -O2 -c ldep.cxx
/bin/sh ./libtool --mode=link g++  -g -O2  -o ldep  ldep.o libidep.a 
g++ -g -O2 -o ldep ldep.o  libidep.a
